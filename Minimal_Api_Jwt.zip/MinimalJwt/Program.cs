using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using MinimalJwt.Models;
using MinimalJwt.Services;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSwaggerGen();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "You api title", Version = "v1" });
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Description = @"JWT Authorization header using the Bearer scheme. \r\n\r\n 
                      Enter 'Bearer' [space] and then your token in the text input below.
                      \r\n\r\nExample: 'Bearer 12345abcdef'",
        Name = "Authorization",
        In = ParameterLocation.Header,
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer"
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                    {
                      new OpenApiSecurityScheme
                      {
                        Reference = new OpenApiReference
                          {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                          },
                          Scheme = "oauth2",
                          Name = "Bearer",
                          In = ParameterLocation.Header,

                        },
                    new List<string>()
                  }
                });
    //var xmlFile = $"{Assembly.GetExecutingAssembly().GetName().Name}.xml";
    //var xmlPath = Path.Combine(AppContext.BaseDirectory, xmlFile);
    //c.IncludeXmlComments(xmlPath);

});

builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidateActor = true,
        ValidateAudience = true,
        ValidateLifetime = true,
        ValidateIssuerSigningKey = true,
        ValidIssuer = builder.Configuration["JWT:ValidIssuer"],
        ValidAudience = builder.Configuration["JWT:ValidAudience"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Secret"]))

    };
});
builder.Services.AddAuthorization();

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSingleton<IMovieService,MovieService>();

builder.Services.AddSingleton<IUserService, UserService>();

var app = builder.Build();

app.UseSwagger();
app.UseAuthorization();
app.UseAuthentication();
app.MapGet("/", () => "Hello World!");

app.MapPost("/login",
    (UserLogin user, IUserService service) => Login(user, service))
    .Accepts<UserLogin>("application/json")
    .Produces<string>();

app.MapPost("/create",
    [Authorize(AuthenticationSchemes =JwtBearerDefaults.AuthenticationScheme,Roles = "Administrator")]
    (Movie movie, IMovieService service) => Create(movie,service))
    .Accepts<Movie>("application/json").Produces<Movie>(statusCode:200,contentType: "application/json");

app.MapGet("/get",
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Standarad, Administrator")]

(int id, IMovieService service) => Get(id, service)).Produces<Movie>();

app.MapGet("/list",
    (IMovieService service) => List(service))
    .Produces<Movie>(statusCode: 200, contentType: "application/json");

app.MapPut("/update",
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Administrator")]

(Movie newMovie, IMovieService service) => Update(newMovie, service));
   

app.MapDelete("/delete",
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme, Roles = "Administrator")]

(int id, IMovieService service) => Delete(id, service));

 IResult Login(UserLogin user,IUserService service)
{
    if(!string.IsNullOrEmpty(user.UserName) &&
       !string.IsNullOrEmpty(user.Password))
     {
        var loggedInUser = service.Get(user);
        if (loggedInUser is null) return Results.NotFound("User not Found");

        var claims = new[]
        {
           new Claim(ClaimTypes.NameIdentifier,loggedInUser.UserName),
           new Claim(ClaimTypes.Email,loggedInUser.EmailAddress),
           new Claim(ClaimTypes.GivenName,loggedInUser.GivenName),
           new Claim(ClaimTypes.Surname,loggedInUser.Surname),
           new Claim(ClaimTypes.Role,loggedInUser.Role)
        };

        var token = new JwtSecurityToken
            (
            issuer: builder.Configuration["JWT:ValidIssuer"],
            audience: builder.Configuration["JWT:ValidAudience"],
            claims: claims,
            expires: DateTime.UtcNow.AddDays(60),
            notBefore: DateTime.UtcNow,
            signingCredentials: new SigningCredentials(
                new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Secret"])),
                SecurityAlgorithms.HmacSha256)
                );
      var tokenString = new JwtSecurityTokenHandler().WriteToken(token);

        return Results.Ok(tokenString);
    }
    return Results.BadRequest("Invalid user credentials");
}


IResult Create(Movie movie, IMovieService service)
{
      var result=service.Create(movie);  
    return Results.Ok(result);  
}

IResult Get(int id, IMovieService service)
{
    var movie = service.Get(id);
    if (movie is null) return Results.NotFound("movie Not Found");
    return Results.Ok(movie);
}

IResult List(IMovieService service)
{
    var movies = service.List();
    
    return Results.Ok(movies);
}
IResult Update(Movie newMovie, IMovieService service)
{
    var updatedMovie = service.Update(newMovie);
    if (updatedMovie is null) return Results.NotFound("movie Not Found");
    return Results.Ok(updatedMovie);
}
IResult Delete(int id, IMovieService service)
{
    var result = service.Delete(id);
    if (!result) return Results.BadRequest("Something went wrong");
    return Results.Ok(result);
}

app.UseSwaggerUI();

app.Run();
  